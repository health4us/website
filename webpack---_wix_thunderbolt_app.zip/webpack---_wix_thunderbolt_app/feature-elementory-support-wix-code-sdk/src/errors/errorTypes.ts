const errorTypes = {
	PARSE: 'parsererror',
	ERROR: 'error',
	ABORT: 'abort',
	TIMEOUT: 'timeout',
}

export { errorTypes }
