const errorMessages = {
	REQUEST_ABORTED_MESSAGE: 'Request aborted',
	TIMEOUT_ERROR_MESSAGE: 'Request timed out',
	DEFAULT_WEB_METHOD_ERROR_MESSAGE: 'Promise in backend function rejected with undefined',
}

export { errorMessages }
