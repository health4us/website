export const name = 'dataWixCodeSdk' as const
export const namespace = 'data' as const
