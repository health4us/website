export const getLodashUrl = (base: string = 'https://static.parastorage.com/') =>
	`${base}unpkg/lodash@4.17.21/lodash.min.js`
