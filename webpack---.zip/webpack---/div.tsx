import React from 'react'

const Div = ({ children, ...props }: any) => <div {...props}>{children}</div>

export default Div
