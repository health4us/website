export const name = 'hoverBox' as const
export const HoverBoxAPISym = Symbol('HoverBoxAPISym')
export const HoverBoxHooksSym = Symbol('HoverBoxHooksSym')
export const ComponentType = 'HoverBox'
