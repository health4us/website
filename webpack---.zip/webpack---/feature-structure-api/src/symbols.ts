export const name = 'structureApi' as const
export const BaseStructureAPISym = Symbol('BaseStructureAPISym')
