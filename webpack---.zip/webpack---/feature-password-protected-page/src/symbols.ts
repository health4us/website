export const PasswordProtectedPageApiSymbol = Symbol('PasswordProtectedPageApi')
export const name = 'passwordProtectedPage' as const

export const DialogComponentId = 'SM_ROOT_COMP'
export const SitePasswordDialogComponentId = 'SM_ROOT_COMP_SITE'
