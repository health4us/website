export const name = 'commonConfig' as const
export const CommonConfigSymbol = Symbol('CommonConfig')
