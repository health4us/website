import DropDownMenuSdk from '@wix/thunderbolt-elements/src/components/DropDownMenu/corvid/DropDownMenu.corvid';


const DropDownMenu = {
  sdk: DropDownMenuSdk
};


export const components = {
  ['DropDownMenu']: DropDownMenu
};

