import VectorImageSdk from '@wix/thunderbolt-elements/src/components/VectorImage/corvid/VectorImage.corvid';


const VectorImage = {
  sdk: VectorImageSdk
};


export const components = {
  ['VectorImage']: VectorImage
};

