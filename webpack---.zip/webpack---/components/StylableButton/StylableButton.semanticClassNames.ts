const semanticClassNames = {
  root: 'button',
  buttonLabel: 'button__label',
  buttonIcon: 'button__icon',
} as const;

export default semanticClassNames;
