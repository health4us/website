export const TestIds = {
  columns: 'columns',
} as const;

export const corvidName = '$w.ColumnStrip';
