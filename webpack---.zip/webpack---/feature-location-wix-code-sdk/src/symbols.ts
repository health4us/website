export const name = 'locationWixCodeSdk' as const
export const namespace = 'location' as const

export const EditorLocationSDKHandlersSymbols = Symbol('EditorLocationSDKHandlers')
