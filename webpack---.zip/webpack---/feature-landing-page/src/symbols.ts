export const name = 'landingPage' as const
export const LandingPageAPISymbol = Symbol('LandingPageAPISymbol')
